<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

This is a port to the SDK of the
[Library Detector add-on](https://addons.mozilla.org/en-US/firefox/addon/library-detector/).
The original Library Detector is written by
[Paul Bakaus](http://paulbakaus.com/) and made available under the
[MIT License](http://www.opensource.org/licenses/mit-license.php).

It only recognizes a subset of the libraries recognized by the original,
just to keep the SDK download package size and on-disk footprint as small
as possible.
