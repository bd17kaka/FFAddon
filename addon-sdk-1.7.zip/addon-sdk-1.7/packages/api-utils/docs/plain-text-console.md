<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

The `plain-text-console` module provides a minimalist implementation
of the [console](dev-guide/console.html) global,
which simply logs all messages to standard output.
